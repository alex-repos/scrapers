module.exports = {

//	'url' : 'mongodb://127.0.0.1:27017/chefDB'
    url: 'mongodb://mo3011:1q2w3e@mongo.onmodulus.net:27017/iwe6veNu'

};